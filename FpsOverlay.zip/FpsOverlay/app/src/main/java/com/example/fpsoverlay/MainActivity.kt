package com.example.fpsoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        val info = TextView(this).apply {
            text = "1) Da el permiso de superposición.\n" +
                "2) Conecta el celular a una PC con depuración USB y ejecuta una sola vez:\n\n" +
                "adb shell pm grant com.example.fpsoverlay android.permission.DUMP\n\n" +
                "3) Inicia el overlay y abre tu juego."
            textSize = 15f
        }
        val perm = Button(this).apply {
            text = "Dar permiso de superposición"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }
        val start = Button(this).apply {
            text = "Iniciar overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Falta el permiso de superposición", Toast.LENGTH_LONG).show()
                } else {
                    startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        }
        val stop = Button(this).apply {
            text = "Detener overlay"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        listOf(info, perm, start, stop).forEach { root.addView(it) }
        setContentView(root)
    }
}
