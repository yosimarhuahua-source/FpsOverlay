package com.example.fpsoverlay

/** Lee los FPS de la app en primer plano usando dumpsys (requiere permiso DUMP concedido por ADB). */
object FpsReader {

    private fun run(vararg cmd: String): List<String> = try {
        val p = Runtime.getRuntime().exec(cmd)
        val out = p.inputStream.bufferedReader().readLines()
        p.waitFor()
        out
    } catch (e: Exception) {
        emptyList()
    }

    private fun foregroundPackage(): String? {
        val line = run("dumpsys", "activity", "activities")
            .firstOrNull { it.contains("mResumedActivity") || it.contains("topResumedActivity") }
            ?: return null
        return Regex("""u0 ([\w.]+)/""").find(line)?.groupValues?.get(1)
    }

    private fun findLayer(pkg: String): String? {
        val layers = run("dumpsys", "SurfaceFlinger", "--list").filter { it.contains(pkg) }
        return layers.firstOrNull { it.contains("SurfaceView") && !it.startsWith("Background") }
            ?: layers.firstOrNull { !it.startsWith("Background") }
            ?: layers.firstOrNull()
    }

    /** Devuelve (paquete, fps) o null si no se pudo leer. */
    fun read(): Pair<String, Int>? {
        val pkg = foregroundPackage() ?: return null
        if (pkg == "com.example.fpsoverlay") return null
        val layer = findLayer(pkg) ?: return null
        val times = run("dumpsys", "SurfaceFlinger", "--latency", layer)
            .drop(1)
            .mapNotNull { it.trim().split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() }
            .filter { it > 0 && it != Long.MAX_VALUE }
        if (times.isEmpty()) return null
        val last = times.max()
        val fps = times.count { it > last - 1_000_000_000L }
        return pkg to fps
    }
}
