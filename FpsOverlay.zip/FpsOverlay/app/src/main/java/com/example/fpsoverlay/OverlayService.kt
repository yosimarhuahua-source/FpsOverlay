package com.example.fpsoverlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.util.concurrent.Executors

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var label: TextView
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        label = TextView(this).apply {
            text = "FPS --"
            textSize = 16f
            setTextColor(Color.GREEN)
            setBackgroundColor(Color.argb(160, 0, 0, 0))
            setPadding(24, 12, 24, 12)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24; y = 80
        }
        wm.addView(label, params)

        running = true
        worker.execute {
            while (running) {
                val result = FpsReader.read()
                ui.post {
                    if (result == null) {
                        label.text = "FPS --\n(sin permiso DUMP)"
                        label.setTextColor(Color.YELLOW)
                    } else {
                        val fps = result.second
                        label.text = "FPS $fps"
                        label.setTextColor(
                            when {
                                fps >= 55 -> Color.GREEN
                                fps >= 30 -> Color.YELLOW
                                else -> Color.RED
                            }
                        )
                    }
                }
                Thread.sleep(1000)
            }
        }
    }

    override fun onDestroy() {
        running = false
        worker.shutdownNow()
        if (::label.isInitialized) wm.removeView(label)
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("fps", "FPS Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, "fps")
            .setContentTitle("FPS Overlay activo")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build()
    }
}
